// dummy.cpp will be compiled if using precompiled headers.

int main()
{
	return 0;
}
